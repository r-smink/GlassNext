<?php
if (!defined('ABSPATH')) exit;

add_filter('manage_gn_submission_posts_columns', function($columns) {
    $new = [];
    foreach ($columns as $key => $label) {
        if ($key === 'title') {
            $new['cb'] = $columns['cb'];
            $new['title'] = 'Aanvraag';
            $new['gn_offer_number'] = 'Offertenummer';
            $new['gn_customer'] = 'Klant / organisatie';
            $new['gn_email'] = 'E-mail';
            $new['gn_status'] = 'Status';
            $new['gn_odoo'] = 'Odoo';
            $new['date'] = 'Datum';
        } elseif ($key !== 'cb') {
            $new[$key] = $label;
        }
    }
    if (!isset($new['cb'])) $new['cb'] = '<input type="checkbox">';
    return $new;
});

add_action('manage_gn_submission_posts_custom_column', function($column, $post_id) {
    switch ($column) {
        case 'gn_offer_number':
            echo esc_html(get_post_meta($post_id, '_gn_offer_number', true));
            break;
        case 'gn_customer':
            echo esc_html(get_post_meta($post_id, '_gn_customer_name', true));
            break;
        case 'gn_email':
            echo esc_html(get_post_meta($post_id, '_gn_email', true));
            break;
        case 'gn_status':
            $status = get_post_meta($post_id, '_gn_status', true) ?: 'nieuw';
            $colors = ['nieuw' => '#1786d8', 'bekeken' => '#b45309', 'afgehandeld' => '#087f5b'];
            $color = $colors[$status] ?? '#64748b';
            echo '<span style="color:' . esc_attr($color) . ';font-weight:700;">' . esc_html(ucfirst($status)) . '</span>';
            break;
        case 'gn_odoo':
            $order_id = get_post_meta($post_id, '_gn_odoo_order_id', true);
            $error = get_post_meta($post_id, '_gn_odoo_error', true);
            if ($order_id) {
                echo '<span style="color:#087f5b;font-weight:700;">✓ Order #' . esc_html($order_id) . '</span>';
            } elseif ($error) {
                echo '<span style="color:#c0392b;" title="' . esc_attr($error) . '">✗ Fout</span>';
            } else {
                echo '<span style="color:#94a3b8;">–</span>';
            }
            break;
    }
}, 10, 2);

add_action('add_meta_boxes', function() {
    add_meta_box('gn_submission_detail', 'Aanvraag details', function($post) {
        $offer_number = get_post_meta($post->ID, '_gn_offer_number', true);
        $customer = get_post_meta($post->ID, '_gn_customer_name', true);
        $contact = get_post_meta($post->ID, '_gn_contact_name', true);
        $email = get_post_meta($post->ID, '_gn_email', true);
        $phone = get_post_meta($post->ID, '_gn_phone', true);
        $address = get_post_meta($post->ID, '_gn_address', true);
        $city = get_post_meta($post->ID, '_gn_city', true);
        $status = get_post_meta($post->ID, '_gn_status', true) ?: 'nieuw';
        $filename = get_post_meta($post->ID, '_gn_filename', true);

        echo '<table class="form-table">';
        echo '<tr><th>Offertenummer</th><td><strong>' . esc_html($offer_number) . '</strong></td></tr>';
        echo '<tr><th>Klant / organisatie</th><td>' . esc_html($customer) . '</td></tr>';
        echo '<tr><th>Contactpersoon</th><td>' . esc_html($contact) . '</td></tr>';
        echo '<tr><th>E-mail</th><td>' . esc_html($email) . '</td></tr>';
        echo '<tr><th>Telefoon</th><td>' . esc_html($phone) . '</td></tr>';
        echo '<tr><th>Adres</th><td>' . esc_html($address) . '</td></tr>';
        echo '<tr><th>Postcode / plaats</th><td>' . esc_html($city) . '</td></tr>';
        echo '<tr><th>Status</th><td>';
        echo '<select name="gn_status">';
        foreach (['nieuw' => 'Nieuw', 'bekeken' => 'Bekeken', 'afgehandeld' => 'Afgehandeld'] as $val => $label) {
            echo '<option value="' . esc_attr($val) . '" ' . selected($status, $val, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></td></tr>';
        $odoo_order_id = get_post_meta($post->ID, '_gn_odoo_order_id', true);
        $odoo_error = get_post_meta($post->ID, '_gn_odoo_error', true);
        echo '<tr><th>Odoo</th><td>';
        if ($odoo_order_id) {
            echo '<span style="color:#087f5b;font-weight:700;">✓ Verkooporder #' . esc_html($odoo_order_id) . ' aangemaakt</span>';
        } elseif ($odoo_error) {
            echo '<span style="color:#c0392b;">✗ Mislukt: ' . esc_html($odoo_error) . '</span>';
        } else {
            echo '<span style="color:#64748b;">Niet gesynchroniseerd (Odoo-koppeling staat uit of stond uit op het moment van indienen).</span>';
        }
        echo '</td></tr>';
        echo '</table>';

        echo '<p style="margin-top:20px;">';
        echo '<a href="' . esc_url(admin_url('admin.php?gn_download_json=1&post_id=' . $post->ID)) . '" class="button button-primary">';
        echo 'JSON bestand downloaden (' . esc_html($filename) . ')';
        echo '</a>';
        echo '</p>';

        // Snijplan PDF en CSV download knoppen
        $pdf_attachment_id = get_post_meta($post->ID, '_gn_plan_pdf_attachment_id', true);
        $csv_attachment_id = get_post_meta($post->ID, '_gn_plan_csv_attachment_id', true);

        if ($pdf_attachment_id || $csv_attachment_id) {
            echo '<h3 style="margin-top:20px;">Snijplan bestanden</h3>';
            echo '<p style="margin-top:10px;">';
            if ($pdf_attachment_id) {
                $pdf_url = wp_get_attachment_url($pdf_attachment_id);
                if ($pdf_url) {
                    echo '<a href="' . esc_url($pdf_url) . '" class="button button-secondary" target="_blank" style="margin-right:8px;">';
                    echo 'Snijplan PDF downloaden';
                    echo '</a>';
                }
            }
            if ($csv_attachment_id) {
                $csv_url = wp_get_attachment_url($csv_attachment_id);
                if ($csv_url) {
                    echo '<a href="' . esc_url($csv_url) . '" class="button button-secondary" target="_blank" style="margin-right:8px;">';
                    echo 'CSV Plotter downloaden';
                    echo '</a>';
                }
            }
            echo '</p>';
        }
    }, 'gn_submission', 'normal', 'high');
});

add_action('save_post_gn_submission', function($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['gn_status'])) {
        update_post_meta($post_id, '_gn_status', sanitize_text_field($_POST['gn_status']));
    }
});
